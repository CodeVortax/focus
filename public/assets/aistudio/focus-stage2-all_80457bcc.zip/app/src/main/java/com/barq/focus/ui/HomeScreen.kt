/*
 * Focus: focus, notes and study tools for Android
 * Copyright (C) 2026 MR.English2008
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3 only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.barq.focus.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Savings
import com.barq.focus.data.Badge
import com.barq.focus.data.Game
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.material.icons.filled.MoreVert
import com.barq.focus.data.Moment
import com.barq.focus.data.support
import com.barq.focus.data.tr
import com.barq.focus.data.trf
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Casino
import kotlinx.coroutines.delay
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Event
import com.barq.focus.data.Weekly
import com.barq.focus.data.dayItems
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.barq.focus.data.CardType
import com.barq.focus.data.Config
import com.barq.focus.data.Db
import com.barq.focus.data.FocusCard
import com.barq.focus.data.Item
import com.barq.focus.data.Store
import com.barq.focus.data.startOfDay
import com.barq.focus.service.Perms
import com.barq.focus.service.Shared
import com.barq.focus.ui.theme.AppTheme
import com.barq.focus.ui.theme.CardSwatches
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import com.barq.focus.ui.theme.FocusBrandFont

fun typeLabel(t: CardType) = tr(when (t) { CardType.STUDY -> "Study"; CardType.TREAT -> "Treat"; CardType.FREE -> "Free" })

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(store: Store, onOpen: (FocusCard) -> Unit, go: (String) -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) { rev++; onPauseOrDispose {} }

    var cards by remember(rev) { mutableStateOf(store.also { it.rollover() }.cards()) }
    val setupOk = remember(rev) { Perms.ready(ctx) && Perms.accessibility(ctx) }
    val running = remember(rev) { cards.firstOrNull { it.id == store.activeCardId } }
    val (done, total) = remember(rev, cards) { store.progress(cards) }
    val look = AppTheme.effective
    val greeting = remember(rev) { store.support(Moment.HOME_GREETING) }.takeIf { look?.homeShowGreeting != false }
    val swipes = remember(rev) { store.shortsSwipes() }
    val shortsMin = remember(rev) { Db.get(ctx).totalsSince("shorts", startOfDay()).values.sum() / 60_000 }

    var showAdd by remember { mutableStateOf(false) }
    var fresh by remember { mutableStateOf<List<Badge>>(emptyList()) }
    val workStreak = remember(rev) { Game.workStreak(store) }
    val lightStreak = remember(rev) { Game.lightStreak(store) }
    val xp = remember(rev) { Game.xp(store) }
    LaunchedEffect(rev) {
        val got = withContext(Dispatchers.IO) { Game.evaluate(ctx, store) }
        if (got.isNotEmpty()) fresh = got
    }
    var showAddMenu by remember { mutableStateOf(false) }
    var layoutId by remember { mutableStateOf(store.homeLayout) }
    var showLayouts by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var userName by remember { mutableStateOf(store.userName) }
    var nameDialog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { if (store.userName.isBlank() && !store.nameAsked) { store.nameAsked = true; nameDialog = true } }
    var pendingTreat by remember { mutableStateOf<FocusCard?>(null) }
    var treatSetup by remember { mutableStateOf<FocusCard?>(null) }
    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val c = pendingTreat
        pendingTreat = null
        if (uri != null && c != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val updated = c.copy(media = uri.toString(), eps = emptyList(), folder = "")
            store.updateCard(updated)
            cards = store.cards()
            onOpen(updated)
        }
    }
    val open: (FocusCard) -> Unit = { c ->
        if (c.type == CardType.TREAT && c.media.isEmpty() && c.eps.isEmpty()) treatSetup = c
        else onOpen(c)
    }
    var showEnd by remember { mutableStateOf(false) }
    var rolling by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<FocusCard?>(null) }
    var cardMenu by remember { mutableStateOf<FocusCard?>(null) }
    var editing by remember { mutableStateOf<FocusCard?>(null) }

    if (menu) HomeMenuPanel(store.menuSide, { menu = false }) { menu = false; go(it) }
    Scaffold { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy((look?.spacingDp ?: 12).dp)) {
            HomeHeader(
                name = userName, onName = { nameDialog = true },
                onLayouts = { showLayouts = true }, onNotes = { go("notes") }, onLibrary = { go("pdfs") }, onMore = { menu = true }
            )
            if (!setupOk) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth().clickable { go("setup") }
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(tr("Setup needed"), fontWeight = FontWeight.SemiBold)
                        Text(tr("Usage access, overlay and accessibility. Tap here."), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            greeting?.let { Text(it, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp)) }
            // the one thing to do next: keep going with the running timer, or start the first subject that still has something to do
            val next = running ?: cards.firstOrNull { it.type == CardType.STUDY && it.dayItems.any { i -> !i.done } }
            next?.let { n ->
                val label = if (running != null) trf("Continue: %s", n.title) else trf("Start: %s", n.title)
                val go1 = { if (running != null) onOpen(n) else open(n) }
                val shape = RoundedCornerShape((look?.buttonRadius ?: 20).dp)
                val mod = Modifier.fillMaxWidth().heightIn(min = if (look?.homePrimaryAction == "normal") 48.dp else 56.dp)
                val txt: @Composable () -> Unit = {
                    Text(label, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                }
                if (look?.homePrimaryAction == "subtle") FilledTonalButton(onClick = go1, modifier = mod, shape = shape) { txt() }
                else Button(onClick = go1, modifier = mod, shape = shape) { txt() }
            }
            // nothing planned: an invitation, not an error (shown even with the companion off, it is a plain empty state)
            if (total == 0) Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr(com.barq.focus.data.Support.POOL.getValue(Moment.HOME_EMPTY).first().text), style = MaterialTheme.typography.bodyLarge)
                    FilledTonalButton(onClick = { showAdd = true }) { Text(tr("Add something small")) }
                }
            }
            if (look?.homeShowProgress != false) {
                var moreOpen by remember { mutableStateOf(false) }
                val lvl = Game.level(xp)
                Card(Modifier.fillMaxWidth().clickable { go("log") }, shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                when {
                                    total == 0 -> tr(Config.freeWord(startOfDay() / 86_400_000L)) + "  ·  " + tr("nothing on your plate")
                                    done == total -> tr("Plate cleared  ·  nothing left")
                                    else -> trf("%d left on your plate (of %d)", total - done, total)
                                },
                                style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 2
                            )
                            IconButton(onClick = { moreOpen = !moreOpen }, Modifier.size(32.dp)) {
                                Icon(if (moreOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, "More")
                            }
                        }
                        if (total > 0) LinearProgressIndicator(
                            progress = { done / total.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatChip("\uD83C\uDF7F " + com.barq.focus.data.hmText(store.bankSec()))
                            StatChip("\uD83D\uDCF1 $swipes")
                            StatChip("\uD83D\uDD25 $workStreak")
                            StatChip(Game.titleOf(lvl).first + " " + trf("Lv %d", lvl))
                        }
                        if (moreOpen) {
                            Text(
                                trf("Shorts today: %d swiped, %d min", swipes, shortsMin) + "  ·  \uD83D\uDEE1\uFE0F $lightStreak",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            val (weekLeft, weekAll) = Weekly.progress(cards)
                            if (weekAll > 0) Text(
                                trf("This week: %d of %d tasks left", weekLeft, weekAll),
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.tertiary
                            )
                            Text(tr(Game.titleOf(lvl).second), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            TextButton(onClick = { go("games") }, contentPadding = PaddingValues(0.dp)) { Text(tr("Take a break")) }
                            AiShareRow({ com.barq.focus.data.DayExport.build(ctx, store) })
                            if (total > 0 && done < total) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    TextButton(onClick = { showEnd = true }, contentPadding = PaddingValues(0.dp)) { Text(tr("End day")) }
                                    Spacer(Modifier.weight(1f))
                                    FilledTonalButton(onClick = { rolling = true }) {
                                        Icon(Icons.Default.Casino, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text(tr("Challenge me"))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            HomeCards(
                layout = layoutId, cards = cards, spentMin = { store.spent(it.id) / 60_000 },
                onOpen = { open(it) }, onMenu = { cardMenu = it }, onAdd = { showAddMenu = true },
                modifier = Modifier.weight(1f)
            )
        }
    }

    if (nameDialog) {
        var draft by remember { mutableStateOf(userName) }
        AlertDialog(
            onDismissRequest = { nameDialog = false },
            title = { Text(tr("What should I call you?")) },
            text = { OutlinedTextField(draft, { draft = it.take(24) }, singleLine = true, label = { Text(tr("Your name")) }) },
            confirmButton = { TextButton(onClick = { store.userName = draft.trim(); userName = draft.trim(); nameDialog = false }) { Text(tr("Save")) } },
            dismissButton = { TextButton(onClick = { nameDialog = false }) { Text(tr("Not now")) } }
        )
    }
    if (showLayouts) LayoutPicker(layoutId, { layoutId = it; store.homeLayout = it; showLayouts = false }) { showLayouts = false }
    if (rolling) {
        // "Challenge me": spin through the subjects that still have tasks, land on one, open it (it then picks a task)
        val cand = cards.filter { it.type == CardType.STUDY && it.dayItems.any { i -> !i.done } }
        var shown by remember { mutableStateOf("") }
        LaunchedEffect(Unit) {
            if (cand.isEmpty()) { rolling = false; return@LaunchedEffect }
            val pick = cand.random()
            repeat(10) { shown = cand.random().title; delay(90) }
            shown = pick.title
            delay(600)
            rolling = false
            Shared.challengeCard = pick.id
            open(pick)
        }
        AlertDialog(
            onDismissRequest = { rolling = false },
            title = { Text(tr("Your challenge")) },
            text = { Text(shown, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) },
            confirmButton = {}
        )
    }
    if (fresh.isNotEmpty()) AlertDialog(
        onDismissRequest = { fresh = emptyList() },
        title = { Text(tr("Badge unlocked!")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                fresh.forEach { b ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BadgeArt(b.id, b.emoji, 56.dp, false); Spacer(Modifier.width(12.dp))
                        Column { Text(tr(b.name), fontWeight = FontWeight.Bold); Text(tr(b.desc), style = MaterialTheme.typography.bodyMedium) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { fresh = emptyList() }) { Text(tr("Nice")) } }
    )
    if (showAddMenu) AlertDialog(
        onDismissRequest = { showAddMenu = false },
        confirmButton = {},
        title = { Text(tr("Add")) },
        text = {
            Column {
                TextButton(onClick = { showAddMenu = false; showAdd = true }) { Text(tr("New card")) }
                TextButton(onClick = { showAddMenu = false; go("import") }) { Text(tr("Import / paste (.foc)")) }
            }
        }
    )
    if (showAdd) AddCardDialog({ showAdd = false }) { c ->
        store.saveCards(cards + c); cards = store.cards(); showAdd = false
    }
    cardMenu?.let { m ->
        AlertDialog(
            onDismissRequest = { cardMenu = null },
            title = { Text(m.title) },
            text = {
                Column {
                    TextButton(onClick = { editing = m; cardMenu = null }) { Text(tr("Edit")) }
                    if (m.type == CardType.TREAT) TextButton(onClick = {
                        cardMenu = null; treatSetup = m
                    }) { Text(tr("Change media / episodes")) }
                    TextButton(onClick = { deleting = m; cardMenu = null }) { Text(tr("Delete")) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { cardMenu = null }) { Text(tr("Cancel")) } }
        )
    }
    editing?.let { e ->
        AddCardDialog({ editing = null }, initial = e) { c ->
            store.saveCards(store.cards().map { if (it.id == c.id) c else it }); cards = store.cards(); editing = null
        }
    }
    treatSetup?.let { t ->
        TreatSetupDialog(
            t, onDismiss = { treatSetup = null },
            onSingle = { pendingTreat = t; treatSetup = null; mediaPicker.launch(arrayOf("video/*", "audio/*")) },
            onSaved = { u ->
                treatSetup = null
                store.updateCard(u); cards = store.cards()
                onOpen(u)
            }
        )
    }
    deleting?.let { d ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(trf("Delete \"%s\"?", d.title)) },
            text = {
                if (d.type == CardType.TREAT) TextButton(onClick = {
                    deleting = null; treatSetup = d
                }) { Text(tr("Change media / episodes")) }
            },
            confirmButton = {
                TextButton(onClick = { store.saveCards(cards.filter { it.id != d.id }); cards = store.cards(); deleting = null }) { Text(tr("Delete")) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(tr("Cancel")) } }
        )
    }
    if (showEnd) {
        val eligible = store.partialEligible(cards)
        AlertDialog(
            onDismissRequest = { showEnd = false },
            title = { Text(tr("End day")) },
            text = {
                Text(
                    if (eligible) trf("You did %d of %d tasks. Take a half episode (+%d min)?", done, total, Config.PARTIAL_BONUS)
                    else trf("You did %d of %d tasks. Under half, so nothing to cash out. Tomorrow's a new day.", done, total)
                )
            },
            confirmButton = {
                if (eligible) TextButton(onClick = { store.cashOutPartial(cards); rev++; showEnd = false }) { Text(trf("Take +%d min", Config.PARTIAL_BONUS)) }
                else TextButton(onClick = { showEnd = false }) { Text(tr("OK")) }
            },
            dismissButton = { if (eligible) TextButton(onClick = { showEnd = false }) { Text(tr("Not now")) } }
        )
    }
}

private fun Modifier.neon(color: Color, pulse: State<Float>): Modifier = this.drawBehind {
    val p = pulse.value
    val corner = 24.dp.toPx()
    val reach = 14.dp.toPx()
    val steps = 6
    for (i in steps downTo 1) {
        val d = reach * i / steps
        drawRoundRect(
            color = color.copy(alpha = (0.33f * p * (1f - (i - 1f) / steps)).coerceIn(0f, 1f)),
            topLeft = Offset(-d, -d),
            size = Size(size.width + 2 * d, size.height + 2 * d),
            cornerRadius = CornerRadius(corner + d),
            style = Stroke(width = reach / steps + 1f)
        )
    }
    drawRoundRect(color = color.copy(alpha = p), size = size, cornerRadius = CornerRadius(corner), style = Stroke(2.dp.toPx()))
}

@Composable
private fun glowModifier(color: Color, on: Boolean): Modifier {
    if (!on) return Modifier
    val pulse = rememberInfiniteTransition(label = "glow").animateFloat(
        initialValue = 0.55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "pulse"
    )
    return Modifier.neon(color, pulse)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun CardTile(c: FocusCard, spentMin: Long, onClick: () -> Unit, onLong: () -> Unit) {
    val col = Color(c.color)
    val t = c.dayItems.size
    val d = c.dayItems.count { it.done }
    val left = t - d
    val glow = c.type == CardType.STUDY && left > 0
    val timeText = if (spentMin > 0) fmtMin(spentMin) else ""
    Column(
        Modifier.fillMaxWidth().height(136.dp)
            .then(glowModifier(col, glow))
            .clip(RoundedCornerShape(24.dp))
            .background(col.copy(alpha = 0.18f))
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            c.title, Modifier.fillMaxWidth(),
            style = MaterialTheme.typography.titleMedium.copy(textDirection = TextDirection.Content),
            textAlign = TextAlign.Start, maxLines = 1
        )
        if (c.type == CardType.STUDY) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                when {
                    t == 0 -> Text(Config.freeWord(c.id), fontWeight = FontWeight.Bold, color = col, style = MaterialTheme.typography.titleMedium)
                    left == 0 -> Text(tr("Plate cleared ✓"), fontWeight = FontWeight.Bold, color = col, style = MaterialTheme.typography.titleMedium)
                    else -> Row(verticalAlignment = Alignment.Bottom) {
                        Text("$left", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = col)
                        Text(
                            "  " + trf("left of %d", t), style = MaterialTheme.typography.labelLarge,
                            maxLines = 1, softWrap = false, modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }
                // bottom row: progress bar + time in the bottom-right corner
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (t > 0) LinearProgressIndicator(
                        progress = { d / t.toFloat() },
                        modifier = Modifier.weight(1f), color = col, trackColor = col.copy(alpha = 0.25f)
                    ) else Spacer(Modifier.weight(1f))
                    if (timeText.isNotEmpty()) Text(
                        timeText, Modifier.padding(start = 10.dp),
                        style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = col, maxLines = 1
                    )
                }
            }
        } else {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(typeLabel(c.type) + if (c.eps.isNotEmpty()) "  ▶ " + c.eps.count { it.done } + "/" + c.eps.size else if (c.media.isNotEmpty()) "  ▶" else "", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = col)
                Text("${c.minutes}m", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = col)
            }
        }
    }
}

@Composable
private fun AddCardDialog(onDismiss: () -> Unit, initial: FocusCard? = null, onAdd: (FocusCard) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: CardType.STUDY) }
    var minutes by remember { mutableStateOf((initial?.minutes ?: 60).toString()) }
    var reward by remember { mutableStateOf((initial?.reward ?: 10).toString()) }
    var lines by remember { mutableStateOf("") }
    var color by remember { mutableStateOf(initial?.let { Color(it.color) } ?: CardSwatches[0]) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr(if (initial == null) "New card" else "Edit card")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    title, { title = it }, label = { Text(tr("Title")) }, singleLine = true,
                    textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Content)
                )
                if (initial == null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardType.values().forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t; minutes = when (t) { CardType.STUDY -> "60"; CardType.TREAT -> "40"; CardType.FREE -> "25" } },
                            label = { Text(typeLabel(t)) }
                        )
                    }
                }
                OutlinedTextField(
                    minutes, { minutes = it.filter(Char::isDigit).take(3) },
                    label = { Text(tr(if (type == CardType.STUDY) "Time budget (min, be generous)" else "Minutes")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                if (type == CardType.STUDY && initial != null) {
                    OutlinedTextField(
                        reward, { reward = it.filter(Char::isDigit).take(3) },
                        label = { Text(tr("Treat reward (min) for finishing the subject")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                if (type == CardType.STUDY && initial == null) {
                    OutlinedTextField(
                        lines, { lines = it }, label = { Text(tr("Tasks (one per line, optional)")) }, minLines = 3, maxLines = 6,
                        textStyle = LocalTextStyle.current.copy(textDirection = TextDirection.Content)
                    )
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CardSwatches.forEach { c ->
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).background(c)
                                .border(if (c == color) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                .clickable { color = c }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    if (initial != null) {
                        onAdd(initial.copy(
                            title = title.trim(), color = color.toArgb(),
                            minutes = (minutes.toIntOrNull() ?: initial.minutes).coerceIn(1, 600),
                            reward = (reward.toIntOrNull() ?: initial.reward).coerceIn(0, 600)
                        ))
                    } else {
                        val items = if (type == CardType.STUDY)
                            lines.lines().map { it.trim() }.filter { it.isNotEmpty() }.map { Item(it, false) } else emptyList()
                        onAdd(FocusCard(System.currentTimeMillis(), title.trim(), type, color.toArgb(), (minutes.toIntOrNull() ?: 60).coerceIn(1, 600), items))
                    }
                }
            ) { Text(tr(if (initial == null) "Add" else "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Cancel")) } }
    )
}

private fun fmtMin(m: Long) = if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"


/**
 * The 3-dots menu: a slim panel of icons that slides in from the side. Slide it inward (or tap the arrow) and the
 * names appear. The side follows the language direction unless Settings picked one.
 */
@Composable
private fun HomeMenuPanel(side: Int, onDismiss: () -> Unit, go: (String) -> Unit) {
    val items = listOf(
        Triple("music", Icons.Default.LibraryMusic, "Music"),
        Triple("games", Icons.Default.SportsEsports, "Games"),
        Triple("trophies", Icons.Default.Star, "Trophies"),
        Triple("projects", Icons.Default.Build, "Projects"),
        Triple("piggy", Icons.Default.Savings, "Piggy bank"),
        Triple("log", Icons.Default.History, "Log"),
        Triple("mistakes", Icons.Default.Edit, "Mistake log"),
        Triple("events", Icons.Default.Event, "Events & meetings"),
        Triple("schedule", Icons.Default.Schedule, "Not-free blocks"),
        Triple("launcher", Icons.Default.Home, "Study launcher"),
        Triple("import", Icons.Default.Add, "Import / Export (.foc)"),
        Triple("theme", Icons.Default.Palette, "Look & theme"),
        Triple("setup", Icons.Default.Settings, "Setup"),
    )
    val rtl = androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
    // auto = the end side, where the 3-dots button is
    val onRight = when (side) { 1 -> false; 2 -> true; else -> !rtl }
    var expanded by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val width by androidx.compose.animation.core.animateDpAsState(if (expanded) 210.dp else 64.dp, label = "menuW")
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null, onClick = onDismiss)) {
            androidx.compose.animation.AnimatedVisibility(
                shown,
                modifier = Modifier.align(if (onRight == !rtl) Alignment.CenterEnd else Alignment.CenterStart),
                enter = androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(240)) { if (onRight) it else -it },
            ) {
                var drag by remember { mutableStateOf(0f) }
                Surface(
                    Modifier.fillMaxHeight().width(width).clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null) {}
                        .pointerInput(onRight) {
                            detectHorizontalDragGestures(
                                onDragStart = { drag = 0f },
                                onHorizontalDrag = { c, dx -> c.consume(); drag += dx },
                                onDragEnd = {
                                    val inward = if (onRight) -drag else drag
                                    if (inward > 40f) expanded = true else if (inward < -40f) expanded = false
                                }
                            )
                        },
                    shape = if (onRight) RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp) else RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp),
                    tonalElevation = 6.dp, shadowElevation = 8.dp
                ) {
                    Column(
                        Modifier.windowInsetsPadding(WindowInsets.systemBars).verticalScroll(rememberScrollState()).padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        IconButton(onClick = { expanded = !expanded }, Modifier.align(Alignment.CenterHorizontally)) {
                            Icon(
                                if (expanded == onRight) Icons.AutoMirrored.Filled.KeyboardArrowRight else Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                tr(if (expanded) "Hide names" else "Show names")
                            )
                        }
                        items.forEach { (route, icon, label) ->
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(16.dp)).clickable { go(route) }.padding(vertical = 12.dp, horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, tr(label), tint = MaterialTheme.colorScheme.primary)
                                if (expanded) Text(tr(label), Modifier.padding(start = 14.dp), maxLines = 1, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            }
        }
    }
}


/** A slim one-line header: "Welcome back, name" (tap the name to change it) and the few icons that used to fill the top bar. */
@Composable
private fun HomeHeader(name: String, onName: () -> Unit, onLayouts: () -> Unit, onNotes: () -> Unit, onLibrary: () -> Unit, onMore: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (name.isBlank()) tr("Welcome back") else trf("Welcome back, %s", name),
            style = MaterialTheme.typography.titleMedium, fontFamily = FocusBrandFont, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable(onClick = onName).padding(horizontal = 6.dp, vertical = 8.dp)
        )
        IconButton(onClick = onLayouts, Modifier.size(40.dp)) { Icon(Icons.Default.ViewModule, "Layout", Modifier.size(22.dp)) }
        IconButton(onClick = onNotes, Modifier.size(40.dp)) { Icon(Icons.Default.Description, "Notes", Modifier.size(22.dp)) }
        IconButton(onClick = onLibrary, Modifier.size(40.dp)) { Icon(Icons.AutoMirrored.Filled.MenuBook, "Library", Modifier.size(22.dp)) }
        IconButton(onClick = onMore, Modifier.size(40.dp)) { Icon(Icons.Default.MoreVert, "More", Modifier.size(22.dp)) }
    }
}

@Composable
private fun StatChip(text: String) {
    Text(
        text, style = MaterialTheme.typography.labelMedium, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 10.dp, vertical = 5.dp)
    )
}
