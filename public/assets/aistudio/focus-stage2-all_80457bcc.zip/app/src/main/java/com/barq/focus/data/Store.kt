/*
 * Focus: focus, notes and study tools for Android
 * Copyright (C) 2026 MR.English2008
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, version 3 only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: AGPL-3.0-only
 */

package com.barq.focus.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

enum class CardType { STUDY, TREAT, FREE }

data class Item(
    val text: String, val done: Boolean,
    val weekly: Boolean = false,      // a this-week task: any day, faster = bigger reward
    val reward: Int = 0,              // weekly: base treat minutes
    val created: Long = 0L,           // weekly: when it was added
    val deadline: Long = 0L,          // weekly: end of its week
    val paid: Boolean = false,        // weekly: reward already given (no double dipping)
    val paidSec: Int = 0,             // weekly: how much was paid, so un-ticking can take it back
    val group: String = "",           // name of the TaskGroup it sits in ("" = none)
    val voice: String = "",           // voice note file name ("" = none)
    val voiceMs: Long = 0L,
    val subs: List<SubTask> = emptyList(),   // small steps inside a big task
)

/** One small step of a task. */
data class SubTask(val text: String, val done: Boolean = false)

/** One video of a treat series. [orig] is the real file name, [locked] means it is renamed so no other app lists it. */
data class Episode(
    val uri: String, val name: String, val ms: Long = 0L, val done: Boolean = false,
    val locked: Boolean = false, val orig: String = ""
)

data class FocusCard(
    val id: Long, val title: String, val type: CardType, val color: Int,
    val minutes: Int, val items: List<Item> = emptyList(),
    val sound: String = "",           // "" = default alarm, "silent", or a ringtone uri
    val reward: Int = 10,             // treat minutes for finishing the WHOLE subject (split across its tasks)
    val media: String = "",           // treat cards: uri of the video/audio to play in the app
    val groups: List<TaskGroup> = emptyList(),
    val eps: List<Episode> = emptyList(),   // treat cards: a series, one episode per token
    val folder: String = "",                // treat cards: the folder (tree uri) the episodes live in, for locking
    val classDays: Int = 0,                 // study cards: bit 0 = Monday .. bit 6 = Sunday; new work arrives on those days
    val examDate: Long = 0L                 // study cards: end of the exam day (millis), 0 = none
)

/** A project: a name and the apps you will use for it. */
data class Project(val id: Long, val name: String, val apps: List<String>)

data class Block(
    val id: Long, val name: String, val startMin: Int, val endMin: Int,
    val lock: Boolean = false,                 // true: only the allowed apps work during this block
    val strict: Boolean = false,               // true: no emergency override
    val allowed: Set<String> = emptySet(),
) {
    fun contains(m: Int) = if (startMin <= endMin) m in startMin until endMin else (m >= startMin || m < endMin)
}

fun minText(sec: Int): String =
    if (sec % 60 == 0) "${sec / 60}" else String.format(java.util.Locale.US, "%.1f", sec / 60f)

/** A countdown as MM:SS, or H:MM:SS once it is an hour or more (used by the timer screen, card and notification). */
fun clockText(totalSec: Long): String {
    val s = if (totalSec < 0) 0 else totalSec
    return if (s >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    else String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60)
}

/** Minutes for short amounts, hours and minutes for long ones: "45 min", "2 h 5 min". */
fun hmText(sec: Int): String {
    val m = sec / 60
    return if (m >= 60) trf("%d h %d min", m / 60, m % 60) else trf("%s min", minText(sec))
}

/**
 * When Focus's "day" begins, as hours after midnight (0 = midnight). Someone who studies until 2 AM wants that time to
 * count for the day they started, so the day can roll over at, say, 4 AM instead. Set by [Store]; read by everything
 * that needs "today".
 */
object DayClock {
    @Volatile var startHour = 0

    /** The clock moved back by the start hour: its calendar date is Focus's "today". */
    fun shifted(now: Long = TrustedClock.now(), plusDays: Int = 0): Calendar =
        Calendar.getInstance().apply { timeInMillis = now - startHour * 3_600_000L; if (plusDays != 0) add(Calendar.DAY_OF_YEAR, plusDays) }

    /** Real time at which the day [offset] days ago began. */
    fun dayStart(offset: Int, now: Long = TrustedClock.now()): Long {
        val c = shifted(now, -offset)
        c.set(Calendar.HOUR_OF_DAY, startHour); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
}

fun startOfDay(): Long = DayClock.dayStart(0)

object Config {
    // package -> label. All of these are logged; only the "gated" ones get the overlay.
    val TRACKED = linkedMapOf(
        "com.google.android.youtube" to "YouTube",
        "com.android.chrome" to "Chrome",
        "com.google.android.apps.youtube.music" to "YouTube Music",
        "org.videolan.vlc" to "VLC",
        "org.telegram.messenger" to "Telegram",
    )
    val DEFAULT_GATED = setOf("com.google.android.youtube", "com.android.chrome")

    // free passes at the gate
    const val SEARCH_MINUTES = 10
    const val LINK_MINUTES = 5
    const val CUSTOM_MINUTES = 10
    const val DISTRACTED_MINUTES = 5
    const val DISTRACTED_WAIT = 15
    const val DELAY_SECONDS = 3
    const val BLOCK_DELAY_SECONDS = 15
    const val SHORTS_GRACE_MIN = 2
    const val STRICT_EXTEND_MIN = 5

    // Shorts gate: fewer choices, passes that run out, waits that grow, rules that loosen slowly
    const val SHORTS_PASS_VIDEOS = 3      // the one "watch more" offer
    const val SHORTS_PASS_MINUTES = 10    // a pass also runs out after this long, even with videos left
    const val SHORTS_MAX_PASSES = 6       // after this many passes in a day, more needs the typed sentence
    const val SHORTS_WAIT_MAX = 30        // the gate wait doubles with every pass, up to this many seconds
    const val LOOSEN_DELAY_MIN = 60       // a looser Shorts rule (higher limit, strict mode off) starts after this long

    // treat bank (minutes), resets every day
    const val SUBJECT_BONUS = 10          // every subject whose checklist is fully done
    const val DAY_BONUS = 40              // the episode: every subject done
    const val PARTIAL_BONUS = 20          // "half episode" if you end the day with >= half done
    const val PARTIAL_MIN_FRACTION = 0.5f
    const val TREAT_STEP = 10             // size of one treat purchase at the gate
    const val ADD_TIME_MIN = 10
    const val WEEKLY_BASE_MIN = 15        // default reward of a this-week task (x2 if done at once, x1 at the deadline)

    // reminders
    const val REMIND_EVERY_MIN = 90
    const val REMIND_FROM_HOUR = 9
    const val REMIND_TO_HOUR = 22

    val FREE_WORDS = listOf(
        "Free prisoner", "Good to go", "Plate's empty", "Chill mode on",
        "Nothing owed", "Zero tasks, full hero", "Off the hook", "Vibes only"
    )
    fun freeWord(seed: Long): String = FREE_WORDS[(Math.abs(seed) % FREE_WORDS.size).toInt()]
}

class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("focus", Context.MODE_PRIVATE)

    init {
        DayClock.startHour = p.getInt("day_start_hour", 0).coerceIn(0, 12)
        TrustedClock.attach(ctx.applicationContext, p)
    }

    /** Hour (0-12) the day rolls over at. */
    var dayStartHour: Int
        get() = p.getInt("day_start_hour", 0).coerceIn(0, 12)
        set(v) { val h = v.coerceIn(0, 12); p.edit().putInt("day_start_hour", h).apply(); DayClock.startHour = h }

    // ---- cards ----
    fun cards(): List<FocusCard> {
        val s = p.getString("cards", null) ?: return emptyList()
        val a = JSONArray(s)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val items = o.optJSONArray("items")?.let { arr ->
                (0 until arr.length()).map { i ->
                    arr.getJSONObject(i).let { x ->
                        Item(
                            x.getString("t"), x.getBoolean("d"), x.optBoolean("w", false), x.optInt("r", 0), x.optLong("c", 0L),
                            x.optLong("dl", 0L), x.optBoolean("p", false), x.optInt("ps", 0), x.optString("g", ""), x.optString("v", ""), x.optLong("vm", 0L),
                            x.optJSONArray("sb")?.let { sa -> (0 until sa.length()).map { k -> sa.getJSONObject(k).let { so -> SubTask(so.optString("t", ""), so.optBoolean("d", false)) } } } ?: emptyList()
                        )
                    }
                }
            } ?: emptyList()
            val groups = o.optJSONArray("groups")?.let { ga ->
                (0 until ga.length()).map { i -> ga.getJSONObject(i).let { g -> TaskGroup(g.getString("n"), g.getInt("c"), g.optBoolean("x", false)) } }
            } ?: emptyList()
            val eps = o.optJSONArray("eps")?.let { ea ->
                (0 until ea.length()).map { i ->
                    ea.getJSONObject(i).let { e ->
                        Episode(e.getString("u"), e.optString("n", ""), e.optLong("ms", 0L), e.optBoolean("d", false), e.optBoolean("l", false), e.optString("o", ""))
                    }
                }
            } ?: emptyList()
            FocusCard(o.getLong("id"), o.getString("title"), CardType.valueOf(o.getString("type")), o.getInt("color"), o.getInt("minutes"), items, o.optString("sound", ""), o.optInt("reward", 10), o.optString("media", ""), groups, eps, o.optString("folder", ""), o.optInt("cd", 0), o.optLong("ex", 0L))
        }
    }

    fun saveCards(l: List<FocusCard>) {
        val a = JSONArray()
        l.forEach { c ->
            val items = JSONArray()
            c.items.forEach {
                items.put(
                    JSONObject().put("t", it.text).put("d", it.done).put("w", it.weekly).put("r", it.reward).put("c", it.created)
                        .put("dl", it.deadline).put("p", it.paid).put("ps", it.paidSec).put("g", it.group).put("v", it.voice).put("vm", it.voiceMs)
                        .put("sb", JSONArray().also { sa -> it.subs.forEach { sx -> sa.put(JSONObject().put("t", sx.text).put("d", sx.done)) } })
                )
            }
            val groups = JSONArray()
            c.groups.forEach { groups.put(JSONObject().put("n", it.name).put("c", it.color).put("x", it.collapsed)) }
            a.put(JSONObject().put("id", c.id).put("title", c.title).put("type", c.type.name)
                .put("color", c.color).put("minutes", c.minutes).put("items", items).put("sound", c.sound).put("reward", c.reward).put("media", c.media).put("groups", groups)
                .put("folder", c.folder).put("cd", c.classDays).put("ex", c.examDate).put("eps", JSONArray().also { ea ->
                    c.eps.forEach { e -> ea.put(JSONObject().put("u", e.uri).put("n", e.name).put("ms", e.ms).put("d", e.done).put("l", e.locked).put("o", e.orig)) }
                }))
        }
        p.edit().putString("cards", a.toString()).apply()
    }

    fun updateCard(c: FocusCard) = saveCards(cards().map { if (it.id == c.id) c else it })

    /**
     * One time: the starter subjects early versions put on a fresh home screen are removed, but only if they were never
     * touched (no tasks, no episodes, no media, no time spent, not running), so nothing the user really uses is lost.
     */
    private fun pruneSeedCards() {
        if (p.getBoolean("seed_pruned", false)) return
        p.edit().putBoolean("seed_pruned", true).apply()
        val seeds = setOf("Chemistry", "Math", "Physics", "Friv project", "Mentalist")
        val all = cards()
        val keys = p.all.keys
        val keep = all.filter { c ->
            // "never used": no time was ever logged for it on any day
            val untouched = keys.none { it.startsWith("spent_") && it.endsWith("_${c.id}") }
            !(c.title in seeds && c.items.isEmpty() && c.eps.isEmpty() && c.media.isEmpty() && c.groups.isEmpty() &&
                c.id != activeCardId && untouched)
        }
        if (keep.size != all.size) saveCards(keep)
    }

    /**
     * New day: finished tasks disappear, unfinished ones carry over. A subject with class days that still has open
     * tasks when new work arrives, or a task past its own due day, counts as a miss (a funny fine, settled by the Vault).
     */
    fun rollover() {
        pruneSeedCards()
        touchDay()
        val d = day()
        val last = p.getInt("last_day", 0)
        if (last != d) {
            p.edit().putInt("last_day", d).apply()
            val dow = (DayClock.shifted().get(Calendar.DAY_OF_WEEK) + 5) % 7      // Monday = 0
            val todayStart = startOfDay()
            val pend = try { org.json.JSONArray(ruleMissPending) } catch (_: Exception) { org.json.JSONArray() }
            var misses = 0; var clean = 0
            val out = cards().map { c ->
                val open = c.dayItems.filter { !it.done }
                val classToday = c.classDays and (1 shl dow) != 0
                val late = open.count { it.deadline in 1..todayStart }
                val missed = if (classToday) open.size else late
                if (last != 0) {
                    if (missed > 0) { misses++; pend.put(org.json.JSONObject().put("c", c.title).put("n", missed).put("d", d)) }
                    else if (classToday && c.dayItems.isNotEmpty()) clean++
                }
                c.copy(items = c.items.filter { !it.done }.map { if (!it.weekly && it.deadline in 1..todayStart) it.copy(deadline = 0L) else it })
            }
            saveCards(out)
            if (misses > 0) { ruleMissPending = pend.toString(); ruleMissTotal += misses }
            if (clean > 0) ruleCleanTotal += clean
        }
        releaseReviews()
        notePlanned(cards())
    }

    // ---- spaced review: a finished task comes back as a short review task after 1, 3 and 7 days ----
    class Review(val cardId: Long, val text: String, val due: Int)

    fun reviews(): List<Review> = try {
        val a = JSONArray(p.getString("reviews", "[]") ?: "[]")
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Review(o.getLong("c"), o.getString("t"), o.getInt("d")) } }
    } catch (_: Exception) { emptyList() }

    private fun saveReviews(l: List<Review>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("c", it.cardId).put("t", it.text).put("d", it.due)) }
        p.edit().putString("reviews", a.toString()).apply()
    }

    private fun dayKeyPlus(n: Int): Int {
        val c = DayClock.shifted(plusDays = n)
        return c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH)
    }

    fun scheduleReviews(cardId: Long, text: String) {
        val t = text.removePrefix("\u21BB ")
        saveReviews(reviews().filter { !(it.cardId == cardId && it.text == t) } + listOf(1, 3, 7).map { Review(cardId, t, dayKeyPlus(it)) })
    }

    /** Reviews that are due today become ordinary tasks on their subject. */
    fun releaseReviews() {
        val all = reviews()
        if (all.isEmpty()) return
        val today = day()
        val (due, later) = all.partition { it.due <= today }
        if (due.isEmpty()) return
        val have = cards()
        saveCards(have.map { c ->
            val mine = due.filter { it.cardId == c.id }.map { "\u21BB " + it.text }.filter { t -> c.items.none { it.text == t && !it.done } }
            if (mine.isEmpty()) c else c.copy(items = c.items + mine.map { Item(it, false) })
        })
        saveReviews(later)
    }

    /** Class-day misses waiting for the Vault to fine them, and lifetime counts for the badges. */
    var ruleMissPending: String
        get() = p.getString("rule_miss_pending", "[]") ?: "[]"
        set(v) { p.edit().putString("rule_miss_pending", v).apply() }
    var ruleMissTotal: Int
        get() = p.getInt("rule_miss_total", 0)
        set(v) { p.edit().putInt("rule_miss_total", v).apply() }
    var ruleCleanTotal: Int
        get() = p.getInt("rule_clean_total", 0)
        set(v) { p.edit().putInt("rule_clean_total", v).apply() }

    /** Remembers the biggest plate you had today. */
    fun notePlanned(cards: List<FocusCard>) {
        val total = cards.filter { it.type == CardType.STUDY }.sumOf { it.dayItems.size }
        if (total > p.getInt("planned_${day()}", 0)) p.edit().putInt("planned_${day()}", total).apply()
    }

    fun progress(cards: List<FocusCard>): Pair<Int, Int> {
        val plan = cards.filter { it.type == CardType.STUDY }
        return plan.sumOf { c -> c.dayItems.count { it.done } } to plan.sumOf { it.dayItems.size }
    }

    // ---- not-free blocks ----
    fun blocks(): List<Block> {
        val s = p.getString("blocks", null) ?: return emptyList()
        val a = JSONArray(s)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Block(
                o.getLong("id"), o.getString("name"), o.getInt("s"), o.getInt("e"),
                o.optBoolean("lock", false), o.optBoolean("strict", false),
                o.optJSONArray("allowed")?.let { a -> (0 until a.length()).map { i -> a.getString(i) }.toSet() } ?: emptySet()
            )
        }
    }

    fun saveBlocks(l: List<Block>) {
        val a = JSONArray()
        l.forEach {
            val al = JSONArray(); it.allowed.forEach { p -> al.put(p) }
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("s", it.startMin).put("e", it.endMin)
                .put("lock", it.lock).put("strict", it.strict).put("allowed", al))
        }
        p.edit().putString("blocks", a.toString()).apply()
    }

    fun activeBlock(): Block? {
        val c = Calendar.getInstance()
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return blocks().firstOrNull { it.contains(m) }
    }

    // ---- gated apps ----
    fun gated(): Set<String> = p.getStringSet("gated", null)?.toSet() ?: Config.DEFAULT_GATED
    fun setGated(s: Set<String>) { p.edit().putStringSet("gated", HashSet(s)).apply() }

    // ---- treat bank ----
    private fun day(): Int {
        val c = DayClock.shifted()
        return c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH)
    }
    private fun flag(n: String) = p.getBoolean("${n}_${day()}", false)
    private fun setFlag(n: String) { p.edit().putBoolean("${n}_${day()}", true).apply() }

    private fun earnedSec() = p.getInt("earnedS_${day()}", 0)
    private fun bonusSec() = p.getInt("bonusS_${day()}", 0)       // piggy-bank payouts: spendable today, but not "earned" (no XP)
    fun addBonusSec(s: Int) { p.edit().putInt("bonusS_${day()}", bonusSec() + s).apply() }
    private fun spentSec() = p.getInt("spentS_${day()}", 0)
    fun earnSec(s: Int) { p.edit().putInt("earnedS_${day()}", (earnedSec() + s).coerceAtLeast(0)).apply() }
    fun spendSec(s: Int) { p.edit().putInt("spentS_${day()}", spentSec() + s).apply() }
    fun earn(min: Int) = earnSec(min * 60)
    fun spend(min: Int) = spendSec(min * 60)
    fun bankSec() = (earnedSec() + bonusSec() - spentSec()).coerceAtLeast(0)
    fun bank() = bankSec() / 60                    // whole minutes (what the gate can sell you)
    fun bankText() = minText(bankSec())

    /**
     * Each subject's reward is split across its tasks: finish 1 of 4 tasks of a 10-min subject = 2.5 min.
     * Un-ticking a task takes its share back (an accidental tick can be undone). Returns seconds gained now (negative = taken back).
     */
    fun settle(cards: List<FocusCard>): Int {
        var gained = 0
        val plan = cards.filter { it.type == CardType.STUDY && it.dayItems.isNotEmpty() }
        for (c in plan) {
            val target = c.reward * 60 * c.dayItems.count { it.done } / c.dayItems.size
            val key = "subs_${day()}_${c.id}"
            val have = p.getInt(key, 0)
            if (target != have) { gained += target - have; p.edit().putInt(key, target).apply() }
        }
        if (plan.isNotEmpty() && plan.all { c -> c.dayItems.all { it.done } } && !flag("day")) {
            setFlag("day")
            if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) < 18 && !p.getBoolean("speedrun", false)) {
                p.edit().putBoolean("speedrun", true).putBoolean("speedrun_by_${day()}", true).apply()
            }
            gained += (Config.DAY_BONUS - (if (flag("partial")) Config.PARTIAL_BONUS else 0)) * 60
        } else if (flag("day") && !(plan.isNotEmpty() && plan.all { c -> c.dayItems.all { it.done } })) {
            // the last task was un-ticked: the whole-day bonus goes back too
            p.edit().remove("day_${day()}").apply()
            if (p.getBoolean("speedrun_by_${day()}", false)) p.edit().remove("speedrun").remove("speedrun_by_${day()}").apply()
            gained -= (Config.DAY_BONUS - (if (flag("partial")) Config.PARTIAL_BONUS else 0)) * 60
        }
        if (gained != 0) earnSec(gained)
        return gained
    }

    fun partialEligible(cards: List<FocusCard>): Boolean {
        val (d, t) = progress(cards)
        return t > 0 && d < t && d.toFloat() / t >= Config.PARTIAL_MIN_FRACTION && !flag("day") && !flag("partial")
    }

    fun cashOutPartial(cards: List<FocusCard>): Int {
        if (!partialEligible(cards)) return 0
        setFlag("partial"); earn(Config.PARTIAL_BONUS)
        return Config.PARTIAL_BONUS
    }

    // ---- study timer (persisted: survives leaving the screen / closing the app) ----
    var activeCardId: Long
        get() = p.getLong("act_id", -1L)
        set(v) { p.edit().putLong("act_id", v).apply() }
    var activeEnd: Long
        get() = p.getLong("act_end", 0L)
        set(v) { p.edit().putLong("act_end", v).apply() }
    var activeStart: Long
        get() = p.getLong("act_start", 0L)
        set(v) { p.edit().putLong("act_start", v).apply() }
    var activePaused: Boolean
        get() = p.getBoolean("act_paused", false)
        set(v) { p.edit().putBoolean("act_paused", v).apply() }
    var activeRemaining: Long                     // ms left while paused (can be negative = over budget)
        get() = p.getLong("act_left", 0L)
        set(v) { p.edit().putLong("act_left", v).apply() }

    fun spent(cardId: Long) = p.getLong("spent_${day()}_$cardId", 0L)
    private fun addSpent(cardId: Long, ms: Long) { p.edit().putLong("spent_${day()}_$cardId", spent(cardId) + ms).apply() }

    fun startActive(cardId: Long, end: Long) {
        stopActive()
        activeCardId = cardId; activeEnd = end; activeStart = System.currentTimeMillis(); activePaused = false
    }

    fun pauseActive() {
        if (activeCardId == -1L || activePaused) return
        val now = System.currentTimeMillis()
        addSpent(activeCardId, (now - activeStart).coerceAtLeast(0L))
        activeRemaining = activeEnd - now
        activePaused = true
    }

    fun resumeActive() {
        if (activeCardId == -1L || !activePaused) return
        val now = System.currentTimeMillis()
        activeEnd = now + activeRemaining
        activeStart = now
        activePaused = false
    }

    /** Adds time; if already over budget, the extra time counts from now. */
    fun addActiveTime(ms: Long) {
        if (activeCardId == -1L) return
        if (activePaused) activeRemaining = maxOf(activeRemaining, 0L) + ms
        else activeEnd = maxOf(activeEnd, System.currentTimeMillis()) + ms
    }

    fun stopActive() {
        val id = activeCardId
        if (id != -1L && !activePaused && System.currentTimeMillis() - activeEnd >= 30 * 60_000L) setFlagNamed("overtime30")
        if (id != -1L && !activePaused) addSpent(id, (System.currentTimeMillis() - activeStart).coerceAtLeast(0L))
        p.edit().remove("act_id").remove("act_end").remove("act_start").remove("act_paused").remove("act_left").apply()
    }

    /**
     * The wall clock was moved by [jump] ms. The running timer's start and end are wall-clock times, so move them with
     * the clock: otherwise setting the clock forward and stopping the timer would credit hours of study that never
     * happened, and setting it back would stretch the budget.
     */
    fun shiftTimer(jump: Long) {
        if (jump == 0L) return
        if (activeCardId != -1L && !activePaused) { activeStart += jump; activeEnd += jump }
        if (lastRemind != 0L) lastRemind += jump
    }

    // ---- projects: a named list of apps; a session spends the treat bank while one of them is on screen ----
    fun projects(): List<Project> {
        val s = p.getString("projects", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Project(o.getLong("id"), o.getString("name"), o.optJSONArray("apps")?.let { x -> (0 until x.length()).map { i -> x.getString(i) } } ?: emptyList())
            }
        } catch (_: Exception) { emptyList() }
    }
    fun saveProjects(l: List<Project>) {
        val a = JSONArray()
        l.forEach { pr -> a.put(JSONObject().put("id", pr.id).put("name", pr.name).put("apps", JSONArray(pr.apps))) }
        p.edit().putString("projects", a.toString()).apply()
    }
    var activeProject: Long
        get() = p.getLong("proj_active", -1L)
        set(v) { p.edit().putLong("proj_active", v).apply() }
    fun projectSec(id: Long): Long = p.getLong("proj_sec_$id", 0L)
    fun projectTotalSec(): Long = projects().sumOf { projectSec(it.id) }
    fun addProjectSec(id: Long, s: Long) { p.edit().putLong("proj_sec_$id", projectSec(id) + s).apply() }
    /** The apps of the running project session: they skip the gate while it runs. */
    fun projectApps(): Set<String> {
        val id = activeProject
        if (id == -1L) return emptySet()
        return projects().firstOrNull { it.id == id }?.apps?.toSet() ?: emptySet()
    }
    fun startProject(id: Long): Boolean {
        if (bankSec() <= 0) return false
        activeProject = id
        return true
    }
    fun stopProject() { activeProject = -1L }

    // ---- piggy bank: unused treat time is saved each day and paid out a week later, with a little interest ----
    var vaultOn: Boolean
        get() = p.getBoolean("vault_on", true)
        set(v) { p.edit().putBoolean("vault_on", v).apply() }
    var vaultLast: Int                           // the last day key that was settled
        get() = p.getInt("vault_last", 0)
        set(v) { p.edit().putInt("vault_last", v).apply() }
    var vaultLots: String
        get() = p.getString("vault_lots", "[]") ?: "[]"
        set(v) { p.edit().putString("vault_lots", v).apply() }
    var vaultLedger: String
        get() = p.getString("vault_ledger", "[]") ?: "[]"
        set(v) { p.edit().putString("vault_ledger", v).apply() }
    var vaultDepositedSec: Long
        get() = p.getLong("vault_dep_total", 0L)
        set(v) { p.edit().putLong("vault_dep_total", v).apply() }
    var vaultInterestSec: Long
        get() = p.getLong("vault_int_total", 0L)
        set(v) { p.edit().putLong("vault_int_total", v).apply() }
    var vaultPayouts: Int
        get() = p.getInt("vault_payouts", 0)
        set(v) { p.edit().putInt("vault_payouts", v).apply() }
    var vaultFines: Int
        get() = p.getInt("vault_fines", 0)
        set(v) { p.edit().putInt("vault_fines", v).apply() }
    var vaultPeakSec: Long
        get() = p.getLong("vault_peak", 0L)
        set(v) { p.edit().putLong("vault_peak", v).apply() }
    /** What was left unspent on a finished day. Piggy-bank payouts are spent first, so interest is never saved again. */
    fun unusedSecOn(dayKey: Int): Int {
        val earned = p.getInt("earnedS_$dayKey", 0); val bonus = p.getInt("bonusS_$dayKey", 0); val spent = p.getInt("spentS_$dayKey", 0)
        return (earned - (spent - bonus).coerceAtLeast(0)).coerceAtLeast(0)
    }

    // ---- reminders ----
    var lastRemind: Long
        get() = p.getLong("last_remind", 0L)
        set(v) { p.edit().putLong("last_remind", v).apply() }

    /** (tasks left, "Math 2 · Physics 3") */
    fun leftSummary(cards: List<FocusCard>): Pair<Int, String> {
        val parts = cards.filter { it.type == CardType.STUDY }
            .map { it to it.dayItems.count { i -> !i.done } }
            .filter { it.second > 0 }
        return parts.sumOf { it.second } to parts.joinToString(" · ") { "${it.first.title} ${it.second}" }
    }

    // ---- "you haven't started" nudges ----
    var startRemind: Boolean
        get() = p.getBoolean("start_remind", true)
        set(v) { p.edit().putBoolean("start_remind", v).apply() }
    var startRemindFrom: Int                      // minute of the day, default 16:00
        get() = p.getInt("start_remind_from", 16 * 60)
        set(v) { p.edit().putInt("start_remind_from", v).apply() }
    var startRemindEvery: Int                     // minutes between nudges, default 60
        get() = p.getInt("start_remind_every", 60)
        set(v) { p.edit().putInt("start_remind_every", v.coerceAtLeast(5)).apply() }
    var lastStartRemind: Long
        get() = p.getLong("last_start_remind", 0L)
        set(v) { p.edit().putLong("last_start_remind", v).apply() }

    /** True once you ticked a task, ran a timer or have one running today. */
    fun workedToday(cards: List<FocusCard>): Boolean =
        activeCardId != -1L || progress(cards).first > 0 ||
            cards.any { it.type == CardType.STUDY && spent(it.id) > 0L }

    // ---- look & feel ----
    var themeMode: Int                            // 0 follow system, 1 light, 2 dark
        get() = p.getInt("theme_mode", 0)
        set(v) { p.edit().putInt("theme_mode", v).apply() }
    var checkShape: Int                           // 0 circle, 1..6 triangle..octagon, 7 mixed
        get() = p.getInt("check_shape", 0)
        set(v) { p.edit().putInt("check_shape", v).apply() }
    var menuSide: Int                             // Home 3-dots panel: 0 follows the language, 1 left, 2 right
        get() = p.getInt("menu_side", 0)
        set(v) { p.edit().putInt("menu_side", v).apply() }
    // ---- study launcher ----
    fun launcherApps(): Set<String> = p.getStringSet("launcher_apps", null)?.toSet() ?: emptySet()
    fun setLauncherApps(s: Set<String>) { p.edit().putStringSet("launcher_apps", HashSet(s)).apply() }
    var launcherCols: Int
        get() = p.getInt("launcher_cols", 4)
        set(v) { p.edit().putInt("launcher_cols", v.coerceIn(3, 5)).apply() }
    var launcherTasks: Boolean
        get() = p.getBoolean("launcher_tasks", true)
        set(v) { p.edit().putBoolean("launcher_tasks", v).apply() }
    var launcherLockUntil: Long                    // study lock end (millis), 0 = none
        get() = p.getLong("launcher_lock_until", 0L)
        set(v) { p.edit().putLong("launcher_lock_until", v).apply() }
    var launcherLockOnTimer: Boolean               // also lock while a subject timer runs
        get() = p.getBoolean("launcher_lock_timer", false)
        set(v) { p.edit().putBoolean("launcher_lock_timer", v).apply() }

    /** The study lock as a strict block: only the launcher's apps (plus Focus, the phone and the system) work. */
    fun studyLock(now: Long): Block? {
        val until = when {
            launcherLockUntil > now -> launcherLockUntil
            launcherLockOnTimer && activeCardId != -1L && !activePaused -> maxOf(activeEnd, now + 60_000L)
            else -> return null
        }
        val c = Calendar.getInstance(); c.timeInMillis = until
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return Block(-99L, "Study lock", 0, m, lock = true, strict = true, allowed = launcherApps())
    }

    var timerCompact: Boolean
        get() = p.getBoolean("timer_compact", false)
        set(v) { p.edit().putBoolean("timer_compact", v).apply() }

    /** Last time the watcher was alive: where a row left open by a killed service really ended. */
    var beat: Long
        get() = p.getLong("beat", 0L)
        set(v) { p.edit().putLong("beat", v).apply() }

    // ---- shorts counter ----
    fun shortsSwipes() = p.getInt("shorts_${day()}", 0)
    fun addShortsSwipe() { p.edit().putInt("shorts_${day()}", shortsSwipes() + 1).apply() }

    // Loosening a Shorts rule (a higher limit, strict mode off) only starts after Config.LOOSEN_DELAY_MIN minutes;
    // tightening is instant. A moment of weakness can no longer undo a decision that was made calmly.
    private fun limitValue(v: Int) = if (v == 0) Int.MAX_VALUE else v      // 0 = no limit = the loosest

    private fun applyPendingRules() {
        val now = System.currentTimeMillis()
        val e = p.edit()
        var changed = false
        val pl = p.getInt("shorts_limit_pending", -1)
        if (pl >= 0 && now >= p.getLong("shorts_limit_pending_at", 0L)) {
            e.putInt("shorts_limit", pl).remove("shorts_limit_pending").remove("shorts_limit_pending_at")
            changed = true
        }
        if (p.contains("strict_off_at") && now >= p.getLong("strict_off_at", 0L)) {
            e.putBoolean("strict_shorts", false).remove("strict_off_at")
            changed = true
        }
        if (changed) e.apply()
    }

    /** Daily Shorts limit in videos (0 = no limit). Reading gives the limit in force right now. */
    var shortsLimit: Int
        get() { applyPendingRules(); return p.getInt("shorts_limit", 30) }
        set(v) {
            applyPendingRules()
            val nv = v.coerceIn(0, 500)
            val cur = p.getInt("shorts_limit", 30)
            if (limitValue(nv) > limitValue(cur)) {
                p.edit().putInt("shorts_limit_pending", nv)
                    .putLong("shorts_limit_pending_at", System.currentTimeMillis() + Config.LOOSEN_DELAY_MIN * 60_000L).apply()
            } else {
                p.edit().putInt("shorts_limit", nv).remove("shorts_limit_pending").remove("shorts_limit_pending_at").apply()
            }
        }

    /** What the settings screen shows: the waiting value if there is one, else the limit in force. */
    fun shortsLimitShown(): Int {
        applyPendingRules()
        val pl = p.getInt("shorts_limit_pending", -1)
        return if (pl >= 0) pl else p.getInt("shorts_limit", 30)
    }

    /** Minutes until a looser Shorts rule that is waiting starts, or 0 when none is waiting. */
    fun shortsLooseningMinutes(): Int {
        applyPendingRules()
        val now = System.currentTimeMillis()
        val a = if (p.getInt("shorts_limit_pending", -1) >= 0) p.getLong("shorts_limit_pending_at", 0L) else 0L
        val b = if (p.contains("strict_off_at")) p.getLong("strict_off_at", 0L) else 0L
        val t = maxOf(a, b)
        return if (t <= now) 0 else ((t - now + 59_999L) / 60_000L).toInt()
    }

    /** How many "watch more" passes were taken today: every pass makes the next gate wait longer. */
    fun shortsPasses() = p.getInt("shorts_passes_${day()}", 0)
    fun addShortsPass() { p.edit().putInt("shorts_passes_${day()}", shortsPasses() + 1).apply() }
    /** When today's current pass runs out (wall-clock ms, 0 = none). */
    fun shortsAllowUntil() = p.getLong("shorts_allow_until_${day()}", 0L)
    fun setShortsAllowUntil(t: Long) { p.edit().putLong("shorts_allow_until_${day()}", t).apply() }
    /** The person's own reason, one sentence, shown at the gate. */
    var shortsWhy: String
        get() = p.getString("shorts_why", "") ?: ""
        set(v) { p.edit().putString("shorts_why", v.trim().take(140)).apply() }
    /** End of a bought treat, kept so that a killed service does not eat minutes that were already paid for. */
    var treatUntilSaved: Long
        get() = p.getLong("treat_until", 0L)
        set(v) { p.edit().putLong("treat_until", v).apply() }

    /** The accessibility service has been on at least once: switching it off afterwards is worth a warning. */
    var a11yEverOn: Boolean
        get() = p.getBoolean("a11y_ever_on", false)
        set(v) { p.edit().putBoolean("a11y_ever_on", v).apply() }

    // ---- mistake log ----
    fun mistakes(): List<Mistake> {
        val s = p.getString("mistakes", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Mistake(
                    id = o.optLong("id"), subject = o.optString("s"), text = o.optString("t"), mine = o.optString("m"),
                    correct = o.optString("c"), cause = o.optInt("w", -1), avoid = o.optString("a"), kind = o.optInt("k"),
                    created = o.optLong("cr"), step = o.optInt("st"), due = o.optLong("d"), done = o.optBoolean("dn")
                )
            }
        } catch (_: Exception) { emptyList() }
    }

    fun saveMistakes(l: List<Mistake>) {
        val a = JSONArray()
        l.forEach { m ->
            a.put(
                JSONObject().put("id", m.id).put("s", m.subject).put("t", m.text).put("m", m.mine).put("c", m.correct)
                    .put("w", m.cause).put("a", m.avoid).put("k", m.kind).put("cr", m.created).put("st", m.step)
                    .put("d", m.due).put("dn", m.done)
            )
        }
        p.edit().putString("mistakes", a.toString()).apply()
    }

    fun addMistake(m: Mistake) = saveMistakes(mistakes() + m)
    /** The swipe count up to which Shorts are allowed today (-1 = the gate has not been passed yet). */
    fun shortsAllow() = p.getInt("shorts_allow_${day()}", -1)
    fun setShortsAllow(n: Int) { p.edit().putInt("shorts_allow_${day()}", n).apply() }

    // ---- treat series: one episode = one token ----
    /** Seconds of watching left on this episode's token (its length plus the free rewind minutes). */
    fun token(cardId: Long, idx: Int): Int = p.getInt("tok_${cardId}_$idx", 0)
    fun setToken(cardId: Long, idx: Int, sec: Int) { p.edit().putInt("tok_${cardId}_$idx", sec.coerceAtLeast(0)).apply() }
    /** Seconds the token was bought with, and the bank seconds it cost: needed to return an episode you barely watched. */
    fun tokenTotal(cardId: Long, idx: Int): Int = p.getInt("toktot_${cardId}_$idx", 0)
    fun tokenCost(cardId: Long, idx: Int): Int = p.getInt("tokcost_${cardId}_$idx", 0)

    /** Pays [costSec] from the bank and opens a token of [totalSec] seconds of watching. */
    fun buyToken(cardId: Long, idx: Int, totalSec: Int, costSec: Int) {
        spendSec(costSec)
        p.edit().putInt("tok_${cardId}_$idx", totalSec).putInt("toktot_${cardId}_$idx", totalSec).putInt("tokcost_${cardId}_$idx", costSec).apply()
    }

    /** Gives an unfinished episode back: the bank gets its cost again and the token is gone. Returns the seconds refunded. */
    fun refundToken(cardId: Long, idx: Int, fallbackCostSec: Int): Int {
        val cost = tokenCost(cardId, idx).takeIf { it > 0 } ?: fallbackCostSec
        p.edit().putInt("spentS_${day()}", (spentSec() - cost).coerceAtLeast(0))
            .remove("tok_${cardId}_$idx").remove("toktot_${cardId}_$idx").remove("tokcost_${cardId}_$idx")
            .remove("media_pos_${cardId}_$idx").apply()
        return cost
    }

    fun markEpisodeDone(cardId: Long, idx: Int) {
        val c = cards().firstOrNull { it.id == cardId } ?: return
        if (idx !in c.eps.indices) return
        updateCard(c.copy(eps = c.eps.mapIndexed { i, e -> if (i == idx) e.copy(done = true) else e }))
        setToken(cardId, idx, 0)
        p.edit().remove("media_pos_${cardId}_$idx").apply()
    }

    // ---- first-run guide ----
    var onboarded: Boolean
        get() = p.getBoolean("onboarded", false)
        set(v) { p.edit().putBoolean("onboarded", v).apply() }
    /** True on a fresh install: nothing saved yet. (Existing users skip the guide; Settings can replay it.) */
    fun isFresh(): Boolean = !onboarded && !p.contains("cards")

    // ---- recordings ----
    var askRecName: Boolean                       // pop up a name box when a recording stops
        get() = p.getBoolean("rec_ask_name", true)
        set(v) { p.edit().putBoolean("rec_ask_name", v).apply() }
    var recKbps: Int                              // Opus bit rate for voice: 24 small, 32 balanced, 64 high
        get() = p.getInt("rec_kbps", 32)
        set(v) { p.edit().putInt("rec_kbps", v).apply() }

    // ---- design theme (Look & theme): the JSON of the applied theme, empty = Focus's own look ----
    var themeJson: String
        get() = p.getString("theme_json", "") ?: ""
        set(v) { p.edit().putString("theme_json", v).apply() }

    // ---- study companion: short kind lines on the gate, the timer and the home screen ----
    var supportOn: Boolean
        get() = p.getBoolean("support_on", true)
        set(v) { p.edit().putBoolean("support_on", v).apply() }
    var supportFreq: Int                          // for toasts: 0 rarely, 1 sometimes, 2 always
        get() = p.getInt("support_freq", 1).coerceIn(0, 2)
        set(v) { p.edit().putInt("support_freq", v.coerceIn(0, 2)).apply() }
    var supportTone: Int                          // 0 any, 1 calm, 2 warm, 3 playful
        get() = p.getInt("support_tone", 0).coerceIn(0, 3)
        set(v) { p.edit().putInt("support_tone", v.coerceIn(0, 3)).apply() }

    // ---- hidden developer options (tap the version 7 times) ----
    var devOptions: Boolean
        get() = p.getBoolean("dev_options", false)
        set(v) { p.edit().putBoolean("dev_options", v).apply() }

    // ---- detection tuning ----
    var debug: Boolean
        get() = p.getBoolean("debug", false)
        set(v) { p.edit().putBoolean("debug", v).apply() }
    var debugIds: String
        get() = p.getString("debug_ids", "") ?: ""
        set(v) { p.edit().putString("debug_ids", v).apply() }

    // ---- timer alert settings ----
    var ringSec: Int
        get() = p.getInt("ring_sec", 30)
        set(v) { p.edit().putInt("ring_sec", v).apply() }
    var nagMin: Int
        get() = p.getInt("nag_min", 5)
        set(v) { p.edit().putInt("nag_min", v).apply() }
    var nagRingSec: Int
        get() = p.getInt("nag_ring_sec", 5)
        set(v) { p.edit().putInt("nag_ring_sec", v).apply() }
    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) { p.edit().putBoolean("speak", v).apply() }
    var alertedEnd: Long
        get() = p.getLong("alerted_end", 0L)
        set(v) { p.edit().putLong("alerted_end", v).apply() }
    var lastNag: Long
        get() = p.getLong("last_nag", 0L)
        set(v) { p.edit().putLong("last_nag", v).apply() }
    val lastCrash: String get() = p.getString("last_crash", "") ?: ""

    // ---- free-time cycle: use the distracting apps for a while, then a break (switching apps doesn't reset the count) ----
    var cycleOn: Boolean
        get() = p.getBoolean("cycle_on", false)
        set(v) { p.edit().putBoolean("cycle_on", v).apply() }
    var cycleAllowMin: Int
        get() = p.getInt("cycle_allow", 60).coerceIn(5, 240)
        set(v) { p.edit().putInt("cycle_allow", v.coerceIn(5, 240)).apply() }
    var cycleBreakMin: Int
        get() = p.getInt("cycle_break", 30).coerceIn(5, 240)
        set(v) { p.edit().putInt("cycle_break", v.coerceIn(5, 240)).apply() }
    var cycleUsed: Long                      // ms of distracting-app time since the last break
        get() = p.getLong("cycle_used", 0L)
        set(v) { p.edit().putLong("cycle_used", v).apply() }
    var cycleBreakUntil: Long                // while in the future, the distracting apps are on a break
        get() = p.getLong("cycle_break_until", 0L)
        set(v) { p.edit().putLong("cycle_break_until", v).apply() }

    /** The small top-of-screen pill (timer, song, charging). Off until switched on in Setup. */
    var pillOn: Boolean
        get() = p.getBoolean("pill_on", false)
        set(v) { p.edit().putBoolean("pill_on", v).apply() }

    // ---- who the home screen greets ----
    var userName: String
        get() = p.getString("user_name", "") ?: ""
        set(v) { p.edit().putString("user_name", v).apply() }
    var nameAsked: Boolean
        get() = p.getBoolean("name_asked", false)
        set(v) { p.edit().putBoolean("name_asked", v).apply() }

    // ---- home layout ----
    var homeLayout: String
        get() = p.getString("home_layout", "grid") ?: "grid"
        set(v) { p.edit().putString("home_layout", v).apply() }

    // ---- notes prefs ----
    var notesGrid: Boolean
        get() = p.getBoolean("notes_grid", true)
        set(v) { p.edit().putBoolean("notes_grid", v).apply() }
    var notesSort: Int                            // 0 last edited, 1 created, 2 title
        get() = p.getInt("notes_sort", 0)
        set(v) { p.edit().putInt("notes_sort", v).apply() }
    var notesAutoSort: Boolean                    // checked items drop to the bottom
        get() = p.getBoolean("notes_autosort", true)
        set(v) { p.edit().putBoolean("notes_autosort", v).apply() }

    // ---- pdf library ----
    fun pdfs(): List<PdfEntry> {
        val a = JSONArray(p.getString("pdfs", "[]") ?: "[]")
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            PdfEntry(o.getString("uri"), o.getString("title"), o.optInt("page", 0), o.optInt("pages", 0))
        }
    }
    fun savePdfs(l: List<PdfEntry>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("uri", it.uri).put("title", it.title).put("page", it.lastPage).put("pages", it.pages)) }
        p.edit().putString("pdfs", a.toString()).apply()
    }
    fun upsertPdf(e: PdfEntry) {
        val l = pdfs()
        savePdfs(if (l.any { it.uri == e.uri }) l.map { if (it.uri == e.uri) e else it } else l + e)
    }
    var pdfNight: Boolean
        get() = p.getBoolean("pdf_night", false)
        set(v) { p.edit().putBoolean("pdf_night", v).apply() }

    // ---- language ----
    var lang: String
        get() = p.getString("lang", null) ?: java.util.Locale.getDefault().language.takeIf { it in setOf("ar", "ru", "de", "fr") } ?: "en"
        set(v) { p.edit().putString("lang", v).apply() }
    fun langPack(code: String): String? = p.getString("langpack_$code", null)
    fun saveLangPack(code: String, json: String) {
        val codes = langCodes().toMutableSet().also { it.add(code) }
        p.edit().putString("langpack_$code", json).putStringSet("langcodes", codes).apply()
    }
    fun langCodes(): Set<String> = p.getStringSet("langcodes", null)?.toSet() ?: emptySet()

    fun putLong(k: String, v: Long) { p.edit().putLong(k, v).apply() }
    fun getLong(k: String): Long = p.getLong(k, 0L)

    // ---- history, streaks, badges ----
    fun touchDay() {
        if (!p.getBoolean("act_${day()}", false)) p.edit().putBoolean("act_${day()}", true).apply()
    }

    fun dayStat(offset: Int): DayStat {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -offset)
        val d = c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH)
        return DayStat(
            d,
            p.getBoolean("act_$d", false) || p.contains("shorts_$d") || p.contains("earnedS_$d"),
            p.getBoolean("day_$d", false), p.getBoolean("partial_$d", false),
            p.getInt("shorts_$d", 0), p.getInt("earnedS_$d", 0), p.getInt("planned_$d", 0)
        )
    }

    fun badges(): Map<String, Int> {
        val o = JSONObject(p.getString("badges", "{}") ?: "{}")
        return o.keys().asSequence().associateWith { o.getInt(it) }
    }
    fun saveBadge(id: String, dayKey: Int) {
        val o = JSONObject(p.getString("badges", "{}") ?: "{}")
        if (!o.has(id)) { o.put(id, dayKey); p.edit().putString("badges", o.toString()).apply() }
    }
    fun challengesAccepted() = p.getInt("challenges_accepted", 0)
    fun challengeAccepted() { p.edit().putInt("challenges_accepted", challengesAccepted() + 1).apply() }
    fun flagSet(name: String) = p.getBoolean(name, false)
    fun setFlagNamed(name: String) { p.edit().putBoolean(name, true).apply() }
    val today: Int get() = day()

    /** The two extra buttons in the music notification / Quick Settings player (ids: shuffle, repeat, heart, back10, fwd10, close). */
    /** Buttons in the music notification, in order (play/pause is always there): prev, next, shuffle, repeat, heart, back10, fwd10, sleep, speed, close. At most 4. */
    var notifBtns: String
        get() = p.getString("notif_btns2", null)
            ?: ("prev,next," + (p.getString("notif_btns", "shuffle,repeat") ?: "shuffle,repeat"))   // older versions kept only the two extras
        set(v) { p.edit().putString("notif_btns2", v).apply() }

    var eqOn: Boolean
        get() = p.getBoolean("eq_on", false)
        set(v) { p.edit().putBoolean("eq_on", v).apply() }
    var eqLevels: String
        get() = p.getString("eq_levels", "") ?: ""
        set(v) { p.edit().putString("eq_levels", v).apply() }
    var eqBass: Int
        get() = p.getInt("eq_bass", 0)
        set(v) { p.edit().putInt("eq_bass", v).apply() }
    var eqPreset: Int
        get() = p.getInt("eq_preset", -1)
        set(v) { p.edit().putInt("eq_preset", v).apply() }

    /** The last music queue, so the player is ready where you left it. Ids of songs, the current one, and the position in ms. */
    var musicQueue: String
        get() = p.getString("music_q", "") ?: ""
        set(v) { p.edit().putString("music_q", v).apply() }
    var musicCurrent: Long
        get() = p.getLong("music_cur", -1L)
        set(v) { p.edit().putLong("music_cur", v).apply() }
    var musicPos: Long
        get() = p.getLong("music_pos", 0L)
        set(v) { p.edit().putLong("music_pos", v).apply() }

    var accent: Int
        get() = p.getInt("accent", 0)
        set(v) { p.edit().putInt("accent", v).apply() }

    /** Strict Shorts mode: gate at once, no "finish this one", no swipe count, extending needs a typed sentence (no paste). */
    var strictShorts: Boolean
        get() { applyPendingRules(); return p.getBoolean("strict_shorts", false) }
        set(v) {
            applyPendingRules()
            if (v) p.edit().putBoolean("strict_shorts", true).remove("strict_off_at").apply()
            else if (p.getBoolean("strict_shorts", false) && !p.contains("strict_off_at"))
                p.edit().putLong("strict_off_at", System.currentTimeMillis() + Config.LOOSEN_DELAY_MIN * 60_000L).apply()
        }

    /** What the switch shows: off as soon as turning it off was asked for, even while it still guards. */
    fun strictShortsShown(): Boolean {
        applyPendingRules()
        return p.getBoolean("strict_shorts", false) && !p.contains("strict_off_at")
    }

    var pdfReader: String                          // "episteme" or "builtin"
        get() = p.getString("pdf_reader", "episteme") ?: "episteme"
        set(v) { p.edit().putString("pdf_reader", v).apply() }

    var pdfMode: Int                               // 0 day, 1 sepia, 2 night
        get() = p.getInt("pdf_mode", if (pdfNight) 2 else 0)
        set(v) { p.edit().putInt("pdf_mode", v).apply() }
    var penStylusOnly: Boolean
        get() = p.getBoolean("pen_stylus_only", false)
        set(v) { p.edit().putBoolean("pen_stylus_only", v).apply() }

    // the drawing tools remember their own colour, size and style
    var pdfTool: Int
        get() = p.getInt("pdf_tool", 0)
        set(v) { p.edit().putInt("pdf_tool", v).apply() }
    var penColor: Int
        get() = p.getInt("pen_color", 0xFF1E88E5.toInt())
        set(v) { p.edit().putInt("pen_color", v).apply() }
    var penSize: Int
        get() = p.getInt("pen_size", 1)
        set(v) { p.edit().putInt("pen_size", v).apply() }
    var penPencil: Boolean
        get() = p.getBoolean("pen_pencil", false)
        set(v) { p.edit().putBoolean("pen_pencil", v).apply() }
    var hiColor: Int
        get() = p.getInt("hi_color", 0xFFFDD835.toInt())
        set(v) { p.edit().putInt("hi_color", v).apply() }
    var hiSize: Int
        get() = p.getInt("hi_size", 1)
        set(v) { p.edit().putInt("hi_size", v).apply() }
    var hiStraight: Boolean
        get() = p.getBoolean("hi_straight", false)
        set(v) { p.edit().putBoolean("hi_straight", v).apply() }
    var inkBarX: Float
        get() = p.getFloat("ink_bar_x", -1f)
        set(v) { p.edit().putFloat("ink_bar_x", v).apply() }
    var inkBarY: Float
        get() = p.getFloat("ink_bar_y", -1f)
        set(v) { p.edit().putFloat("ink_bar_y", v).apply() }

    fun bookmarks(uri: String): List<Int> =
        (p.getString("bm_${uri.hashCode()}", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.sorted()

    fun toggleBookmark(uri: String, page: Int): List<Int> {
        val cur = bookmarks(uri).toMutableList()
        if (!cur.remove(page)) cur.add(page)
        cur.sort()
        p.edit().putString("bm_${uri.hashCode()}", cur.joinToString(",")).apply()
        return cur
    }

    // ---- music: playlists + favourites ----
    fun playlists(): Map<String, List<Long>> {
        val o = JSONObject(p.getString("playlists", "{}") ?: "{}")
        val out = LinkedHashMap<String, List<Long>>()
        o.keys().forEach { k -> val a = o.getJSONArray(k); out[k] = (0 until a.length()).map { a.getLong(it) } }
        return out
    }
    fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        p.edit().putString("playlists", o.toString()).apply()
    }
    fun favorites(): Set<Long> = (p.getString("fav_ids", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.toSet()
    fun toggleFavorite(id: Long): Set<Long> {
        val f = favorites().toMutableSet()
        if (!f.remove(id)) f.add(id)
        p.edit().putString("fav_ids", f.joinToString(",")).apply()
        return f
    }
}

data class PdfEntry(val uri: String, val title: String, val lastPage: Int, val pages: Int)

data class DayStat(
    val key: Int, val active: Boolean, val allDone: Boolean, val partial: Boolean,
    val swipes: Int, val earnedSec: Int, val planned: Int = 0
)
